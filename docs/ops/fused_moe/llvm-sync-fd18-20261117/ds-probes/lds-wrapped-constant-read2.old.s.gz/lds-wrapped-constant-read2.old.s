	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx946"
	.globl	no_wrap_field                   ; -- Begin function no_wrap_field
	.p2align	8
	.type	no_wrap_field,@function
no_wrap_field:                          ; @no_wrap_field
; %bb.0:
	v_and_b32_e32 v0, 0x378, v0
	ds_read2_b64 v[0:3], v0 offset0:4 offset1:8
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel no_wrap_field
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 8
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	no_wrap_field, .Lfunc_end0-no_wrap_field
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 52
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	no_wrap_lowmask                 ; -- Begin function no_wrap_lowmask
	.p2align	8
	.type	no_wrap_lowmask,@function
no_wrap_lowmask:                        ; @no_wrap_lowmask
; %bb.0:
	v_and_b32_e32 v0, 0x378, v0
	ds_read2_b64 v[0:3], v0 offset0:4 offset1:12
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel no_wrap_lowmask
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 8
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end1:
	.size	no_wrap_lowmask, .Lfunc_end1-no_wrap_lowmask
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 52
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	may_wrap_field                  ; -- Begin function may_wrap_field
	.p2align	8
	.type	may_wrap_field,@function
may_wrap_field:                         ; @may_wrap_field
; %bb.0:
	v_and_b32_e32 v0, 0x3f8, v0
	v_add_u32_e32 v1, 32, v0
	v_add_u32_e32 v0, 64, v0
	v_and_b32_e32 v1, 0x3f8, v1
	v_and_b32_e32 v2, 0x3f8, v0
	ds_read_b64 v[0:1], v1
	ds_read_b64 v[2:3], v2
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel may_wrap_field
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 8
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end2:
	.size	may_wrap_field, .Lfunc_end2-may_wrap_field
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 84
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	mask_has_hole                   ; -- Begin function mask_has_hole
	.p2align	8
	.type	mask_has_hole,@function
mask_has_hole:                          ; @mask_has_hole
; %bb.0:
	v_and_b32_e32 v0, 0x3f8, v0
	v_add_u32_e32 v1, 32, v0
	v_add_u32_e32 v0, 64, v0
	v_and_b32_e32 v1, 0x3e8, v1
	v_and_b32_e32 v2, 0x3e8, v0
	ds_read_b64 v[0:1], v1
	ds_read_b64 v[2:3], v2
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel mask_has_hole
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 8
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end3:
	.size	mask_has_hole, .Lfunc_end3-mask_has_hole
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 84
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.section	".note.GNU-stack","",@progbits
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 8
    .max_flat_workgroup_size: 1024
    .name:           no_wrap_field
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         no_wrap_field.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 8
    .max_flat_workgroup_size: 1024
    .name:           no_wrap_lowmask
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         no_wrap_lowmask.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 8
    .max_flat_workgroup_size: 1024
    .name:           may_wrap_field
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         may_wrap_field.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 8
    .max_flat_workgroup_size: 1024
    .name:           mask_has_hole
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         mask_has_hole.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx946
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
