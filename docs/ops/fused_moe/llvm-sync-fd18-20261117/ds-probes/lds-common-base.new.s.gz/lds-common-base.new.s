	.text
	.amdgcn_target "amdgcn-amd-amdhsa--gfx946"
	.globl	wrapped_overlap                 ; -- Begin function wrapped_overlap
	.p2align	8
	.type	wrapped_overlap,@function
wrapped_overlap:                        ; @wrapped_overlap
; %bb.0:
	v_and_b32_e32 v1, 0x398, v0
	v_and_b32_e32 v0, 24, v0
	v_add_u32_e32 v0, v0, v1
	ds_read2_b64 v[0:3], v0 offset0:4 offset1:132
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel wrapped_overlap
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 8
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	wrapped_overlap, .Lfunc_end0-wrapped_overlap
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 60
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	wrapped_disjoint                ; -- Begin function wrapped_disjoint
	.p2align	8
	.type	wrapped_disjoint,@function
wrapped_disjoint:                       ; @wrapped_disjoint
; %bb.0:
	v_and_b32_e32 v0, 0x3d8, v0
	v_add_u32_e32 v0, 32, v0
	ds_read2st64_b64 v[0:3], v0 offset1:4
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel wrapped_disjoint
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 8
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end1:
	.size	wrapped_disjoint, .Lfunc_end1-wrapped_disjoint
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 56
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	typed_gep                       ; -- Begin function typed_gep
	.p2align	8
	.type	typed_gep,@function
typed_gep:                              ; @typed_gep
; %bb.0:
	s_load_dword s0, s[4:5], 0x8
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v0, s0
	ds_read2st64_b64 v[0:3], v0 offset0:12 offset1:14
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel typed_gep
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end2:
	.size	typed_gep, .Lfunc_end2-typed_gep
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 60
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 1
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	negative_delta                  ; -- Begin function negative_delta
	.p2align	8
	.type	negative_delta,@function
negative_delta:                         ; @negative_delta
; %bb.0:
	s_load_dword s0, s[4:5], 0x8
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v0, s0
	ds_read2st64_b64 v[0:3], v0 offset0:10 offset1:12
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v2, v0
	v_addc_co_u32_e32 v1, vcc, v3, v1, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel negative_delta
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end3:
	.size	negative_delta, .Lfunc_end3-negative_delta
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 60
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 1
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	volatile_load                   ; -- Begin function volatile_load
	.p2align	8
	.type	volatile_load,@function
volatile_load:                          ; @volatile_load
; %bb.0:
	s_load_dword s0, s[4:5], 0x8
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v2, s0
	ds_read_b64 v[0:1], v2 offset:6144
	ds_read_b64 v[2:3], v2 offset:7168
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel volatile_load
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end4:
	.size	volatile_load, .Lfunc_end4-volatile_load
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 68
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 1
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	unknown_or                      ; -- Begin function unknown_or
	.p2align	8
	.type	unknown_or,@function
unknown_or:                             ; @unknown_or
; %bb.0:
	s_load_dword s0, s[4:5], 0x8
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v0, s0
	s_or_b32 s0, s0, 0x420
	v_mov_b32_e32 v2, s0
	ds_read_b64 v[0:1], v0
	ds_read_b64 v[2:3], v2
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel unknown_or
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end5:
	.size	unknown_or, .Lfunc_end5-unknown_or
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 80
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 1
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	variable_offset                 ; -- Begin function variable_offset
	.p2align	8
	.type	variable_offset,@function
variable_offset:                        ; @variable_offset
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v0, s2
	s_add_i32 s2, s2, s3
	v_mov_b32_e32 v2, s2
	ds_read_b64 v[0:1], v0
	ds_read_b64 v[2:3], v2
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel variable_offset
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end6:
	.size	variable_offset, .Lfunc_end6-variable_offset
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 68
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 1
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	barrier                         ; -- Begin function barrier
	.p2align	8
	.type	barrier,@function
barrier:                                ; @barrier
; %bb.0:
	s_load_dword s0, s[4:5], 0x8
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v2, s0
	ds_read_b64 v[0:1], v2
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b64 v[2:3], v2 offset:1024
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel barrier
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end7:
	.size	barrier, .Lfunc_end7-barrier
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 76
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 1
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	aliasing_store                  ; -- Begin function aliasing_store
	.p2align	8
	.type	aliasing_store,@function
aliasing_store:                         ; @aliasing_store
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v0, 0
	v_mov_b32_e32 v1, v0
	s_waitcnt lgkmcnt(0)
	v_mov_b32_e32 v4, s2
	v_mov_b32_e32 v5, s3
	ds_read_b64 v[2:3], v4
	ds_write_b64 v5, v[0:1]
	ds_read_b64 v[4:5], v4 offset:1024
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v1, vcc, v2, v4
	v_addc_co_u32_e32 v2, vcc, v3, v5, vcc
	global_store_dwordx2 v0, v[1:2], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel aliasing_store
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 6
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end8:
	.size	aliasing_store, .Lfunc_end8-aliasing_store
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 76
; NumSgprs: 10
; NumVgprs: 6
; ScratchSize: 0
; MemoryBound: 1
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 6
; Occupancy: 8
; WaveLimiterHint : 1
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	mask_with_hole                  ; -- Begin function mask_with_hole
	.p2align	8
	.type	mask_with_hole,@function
mask_with_hole:                         ; @mask_with_hole
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s2, s2, 0x3398
	s_add_i32 s2, s2, s3
	s_and_b32 s3, s2, 0x5ff
	s_addk_i32 s2, 0x420
	s_and_b32 s2, s2, 0x5ff
	v_mov_b32_e32 v0, s3
	v_mov_b32_e32 v2, s2
	ds_read_b64 v[0:1], v0
	ds_read_b64 v[2:3], v2
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel mask_with_hole
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end9:
	.size	mask_with_hole, .Lfunc_end9-mask_with_hole
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 96
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	overlapping_or                  ; -- Begin function overlapping_or
	.p2align	8
	.type	overlapping_or,@function
overlapping_or:                         ; @overlapping_or
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	s_add_i32 s4, s2, s3
	s_or_b32 s2, s2, 32
	s_add_i32 s2, s2, s3
	s_and_b32 s4, s4, 0x3ff
	s_and_b32 s2, s2, 0x3ff
	v_mov_b32_e32 v0, s4
	v_mov_b32_e32 v2, s2
	ds_read_b64 v[0:1], v0
	ds_read_b64 v[2:3], v2
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel overlapping_or
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end10:
	.size	overlapping_or, .Lfunc_end10-overlapping_or
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 92
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	masked_reassociated_sum         ; -- Begin function masked_reassociated_sum
	.p2align	8
	.type	masked_reassociated_sum,@function
masked_reassociated_sum:                ; @masked_reassociated_sum
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s2, s2, 0x198
	s_and_b32 s3, s3, 48
	s_add_i32 s2, s2, s3
	v_mov_b32_e32 v0, s2
	ds_read2_b64 v[0:3], v0 offset0:4 offset1:132
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel masked_reassociated_sum
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end11:
	.size	masked_reassociated_sum, .Lfunc_end11-masked_reassociated_sum
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 68
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	masked_carry_from_hole          ; -- Begin function masked_carry_from_hole
	.p2align	8
	.type	masked_carry_from_hole,@function
masked_carry_from_hole:                 ; @masked_carry_from_hole
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	s_and_b32 s4, s2, 0x198
	s_and_b32 s3, s3, 48
	s_and_b32 s2, s2, 0x398
	s_add_i32 s4, s4, s3
	s_add_i32 s2, s3, s2
	s_add_i32 s4, s4, 32
	s_add_i32 s2, s2, 32
	s_and_b32 s3, s4, 0x1f8
	s_and_b32 s2, s2, 0x5f8
	v_mov_b32_e32 v0, s3
	v_mov_b32_e32 v2, s2
	ds_read_b64 v[0:1], v0
	ds_read_b64 v[2:3], v2 offset:1024
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel masked_carry_from_hole
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end12:
	.size	masked_carry_from_hole, .Lfunc_end12-masked_carry_from_hole
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 116
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	loop_nested_disjoint_or         ; -- Begin function loop_nested_disjoint_or
	.p2align	8
	.type	loop_nested_disjoint_or,@function
loop_nested_disjoint_or:                ; @loop_nested_disjoint_or
; %bb.0:                                ; %entry
	s_load_dwordx2 s[0:1], s[4:5], 0x0
	s_load_dword s6, s[4:5], 0x8
	v_and_b32_e32 v1, 0x398, v0
	v_or_b32_e32 v0, 32, v1
	v_or_b32_e32 v1, 0x420, v1
	s_mov_b32 s2, 0
	v_mov_b32_e32 v2, 0
.LBB13_1:                               ; %loop
                                        ; =>This Inner Loop Header: Depth=1
	s_lshl_b32 s4, s2, 14
	s_and_b32 s7, s4, 0x4000
	v_or_b32_e32 v3, s7, v0
	v_or_b32_e32 v5, s7, v1
	ds_read_b64 v[3:4], v3
	ds_read_b64 v[5:6], v5
	s_ashr_i32 s3, s2, 31
	s_lshl_b64 s[4:5], s[2:3], 3
	s_waitcnt lgkmcnt(0)
	s_add_u32 s4, s0, s4
	s_addc_u32 s5, s1, s5
	s_add_i32 s2, s2, 1
	v_add_co_u32_e32 v3, vcc, v3, v5
	s_cmp_lt_u32 s2, s6
	v_addc_co_u32_e32 v4, vcc, v4, v6, vcc
	global_store_dwordx2 v2, v[3:4], s[4:5]
	s_cbranch_scc1 .LBB13_1
; %bb.2:                                ; %end
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel loop_nested_disjoint_or
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 12
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 7
		.amdhsa_next_free_sgpr 8
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end13:
	.size	loop_nested_disjoint_or, .Lfunc_end13-loop_nested_disjoint_or
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 132
; NumSgprs: 12
; NumVgprs: 7
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 12
; NumVGPRsForWavesPerEU: 7
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	variable_disjoint_or            ; -- Begin function variable_disjoint_or
	.p2align	8
	.type	variable_disjoint_or,@function
variable_disjoint_or:                   ; @variable_disjoint_or
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	s_add_i32 s4, s2, s3
	s_or_b32 s2, s2, s3
	v_mov_b32_e32 v0, s4
	v_mov_b32_e32 v2, s2
	ds_read_b64 v[0:1], v0
	ds_read_b64 v[2:3], v2 offset:1024
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel variable_disjoint_or
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end14:
	.size	variable_disjoint_or, .Lfunc_end14-variable_disjoint_or
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 72
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.text
	.globl	variable_overlapping_or         ; -- Begin function variable_overlapping_or
	.p2align	8
	.type	variable_overlapping_or,@function
variable_overlapping_or:                ; @variable_overlapping_or
; %bb.0:
	s_load_dwordx4 s[0:3], s[4:5], 0x0
	v_mov_b32_e32 v4, 0
	s_waitcnt lgkmcnt(0)
	s_add_i32 s4, s2, s3
	s_or_b32 s2, s2, s3
	v_mov_b32_e32 v0, s4
	v_mov_b32_e32 v2, s2
	ds_read_b64 v[0:1], v0
	ds_read_b64 v[2:3], v2 offset:1024
	s_waitcnt lgkmcnt(0)
	v_add_co_u32_e32 v0, vcc, v0, v2
	v_addc_co_u32_e32 v1, vcc, v1, v3, vcc
	global_store_dwordx2 v4, v[0:1], s[0:1]
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel variable_overlapping_or
		.amdhsa_group_segment_fixed_size 65536
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 16
		.amdhsa_user_sgpr_count 6
		.amdhsa_user_sgpr_private_segment_buffer 1
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_flat_scratch_init 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_system_sgpr_private_segment_wavefront_offset 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 5
		.amdhsa_next_free_sgpr 6
		.amdhsa_reserve_flat_scratch 0
		.amdhsa_reserve_xnack_mask 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_matrix_excp 0
		.amdhsa_cancellation_excp 0
		.amdhsa_vgpr_alloc_mode 0
		.amdhsa_bf16_overflow 0
		.amdhsa_bf8_overflow 0
		.amdhsa_fp8_overflow 0
		.amdhsa_bf16_denorm_mode 3
		.amdhsa_scale_buffer_size 0
		.amdhsa_tf32_overflow 0
		.amdhsa_tf32_denorm_mode 3
		.amdhsa_bf16_rounding_mode 0
		.amdhsa_uc_cc_ack_early_return 1
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end15:
	.size	variable_overlapping_or, .Lfunc_end15-variable_overlapping_or
                                        ; -- End function
	.section	.AMDGPU.csdata,"",@progbits
; Kernel info:
; codeLenInByte = 72
; NumSgprs: 10
; NumVgprs: 5
; ScratchSize: 0
; MemoryBound: 0
; LatencyBound: 0
; FloatMode: 240
; IeeeMode: 1
; LDSByteSize: 65536 bytes/workgroup (compile time only)
; SGPRBlocks: 1
; VGPRBlocks: 1
; NumSGPRsForWavesPerEU: 10
; NumVGPRsForWavesPerEU: 5
; Occupancy: 8
; WaveLimiterHint : 0
; COMPUTE_PGM_RSRC2:SCRATCH_EN: 0
; COMPUTE_PGM_RSRC2:USER_SGPR: 6
; COMPUTE_PGM_RSRC2:TRAP_HANDLER: 0
; COMPUTE_PGM_RSRC2:TGID_X_EN: 1
; COMPUTE_PGM_RSRC2:TGID_Y_EN: 0
; COMPUTE_PGM_RSRC2:TGID_Z_EN: 0
; COMPUTE_PGM_RSRC2:TIDIG_COMP_CNT: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:FP8_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX938:BF16_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:SCALE_BUFFER_SIZE: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_OVFL: 0
; COMPUTE_PGM_RSRC3_GFX946:TF32_DENORM: 3
; COMPUTE_PGM_RSRC3_GFX946:BF16_RMODE: 0
; COMPUTE_PGM_RSRC3_GFX946:UC_CC_ACK_EARLY_RETURN: 1
	.section	".note.GNU-stack","",@progbits
	.amdgpu_metadata
---
amdhsa.kernels:
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 8
    .max_flat_workgroup_size: 1024
    .name:           wrapped_overlap
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         wrapped_overlap.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 8
    .max_flat_workgroup_size: 1024
    .name:           wrapped_disjoint
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         wrapped_disjoint.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           typed_gep
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         typed_gep.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           negative_delta
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         negative_delta.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           volatile_load
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         volatile_load.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           !str off
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           unknown_or
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         unknown_or.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           !str off
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           !str off
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           variable_offset
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         variable_offset.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           !str off
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           barrier
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         barrier.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           aliasing_store
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         aliasing_store.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .address_space:  local
        .name:           alias
        .offset:         12
        .pointee_align:  1
        .size:           4
        .value_kind:     dynamic_shared_pointer
    .uses_dynamic_stack: false
    .vgpr_count:     6
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           mask_with_hole
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         mask_with_hole.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           overlapping_or
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         overlapping_or.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           wave
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           masked_reassociated_sum
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         masked_reassociated_sum.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           wave
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           wave
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           masked_carry_from_hole
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         masked_carry_from_hole.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           idx
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           wave
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           count
        .offset:         8
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 12
    .max_flat_workgroup_size: 1024
    .name:           loop_nested_disjoint_or
    .private_segment_fixed_size: 0
    .sgpr_count:     12
    .sgpr_spill_count: 0
    .symbol:         loop_nested_disjoint_or.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           count
        .offset:         8
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     7
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           x
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           variable_disjoint_or
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         variable_disjoint_or.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           x
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
  - .args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           x
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .group_segment_fixed_size: 65536
    .kernarg_segment_align: 8
    .kernarg_segment_size: 16
    .max_flat_workgroup_size: 1024
    .name:           variable_overlapping_or
    .private_segment_fixed_size: 0
    .sgpr_count:     10
    .sgpr_spill_count: 0
    .symbol:         variable_overlapping_or.kd
    .unfolded_args:
      - .address_space:  global
        .name:           out
        .offset:         0
        .size:           8
        .value_kind:     global_buffer
      - .name:           x
        .offset:         8
        .size:           4
        .value_kind:     by_value
      - .name:           y
        .offset:         12
        .size:           4
        .value_kind:     by_value
    .uses_dynamic_stack: false
    .vgpr_count:     5
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx946
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
